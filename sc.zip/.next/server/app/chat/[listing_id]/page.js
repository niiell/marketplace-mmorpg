(()=>{var e={};e.id=342,e.ids=[342],e.modules={995:(e,t,r)=>{Promise.resolve().then(r.bind(r,54431))},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:e=>{"use strict";e.exports=require("punycode")},12186:(e,t,r)=>{Promise.resolve().then(r.bind(r,78564))},14329:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>i});var n=r(60687);function i({error:e,reset:t}){return(0,n.jsx)("html",{lang:"id",children:(0,n.jsxs)("body",{style:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"100vh",background:"#fef2f2"},children:[(0,n.jsx)("h2",{style:{color:"#b91c1c",fontWeight:"bold",fontSize:"2rem",marginBottom:"1rem"},children:"Terjadi Error"}),(0,n.jsx)("p",{style:{color:"#dc2626",marginBottom:"0.5rem"},children:e?.message||"Unknown error"}),(0,n.jsx)("pre",{style:{fontSize:"0.75rem",color:"#64748b",background:"#f1f5f9",padding:"0.5rem",borderRadius:"0.25rem",maxWidth:600,overflowX:"auto"},children:e?.stack||"No stacktrace"}),(0,n.jsx)("form",{children:(0,n.jsx)("button",{type:"submit",onClick:()=>t(),style:{marginTop:"1rem",padding:"0.5rem 1rem",background:"#2563eb",color:"white",borderRadius:"0.25rem"},children:"Coba Lagi"})})]})})}},16189:(e,t,r)=>{"use strict";var n=r(65773);r.o(n,"useParams")&&r.d(t,{useParams:function(){return n.useParams}}),r.o(n,"useRouter")&&r.d(t,{useRouter:function(){return n.useRouter}})},16391:(e,t,r)=>{"use strict";r.d(t,{N:()=>n});let n=(0,r(94025).UU)("https://zufbkrlgkyqsozaukoxy.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1ZmJrcmxna3lxc296YXVrb3h5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU4MDY3MjcsImV4cCI6MjA2MTM4MjcyN30.YKBK5MCIGHfsQkoko7OesaJ62IueqAIOfQCLm4-BZ54",{auth:{autoRefreshToken:!0,persistSession:!0,detectSessionInUrl:!0},global:{headers:{"Content-Type":"application/json"}}})},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21741:(e,t,r)=>{"use strict";r.d(t,{Providers:()=>s});var n=r(60687),i=r(84492);function s({children:e,locale:t="id",messages:r={}}){return(0,n.jsx)(i.Dk,{messages:r,locale:t,children:e})}},23933:(e,t,r)=>{Promise.resolve().then(r.bind(r,96861)),Promise.resolve().then(r.bind(r,21741))},27910:e=>{"use strict";e.exports=require("stream")},28669:(e,t,r)=>{Promise.resolve().then(r.bind(r,60534)),Promise.resolve().then(r.bind(r,29519))},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29519:(e,t,r)=>{"use strict";r.d(t,{Providers:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\providers.tsx","Providers")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},36404:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>a.a,__next_app__:()=>u,pages:()=>c,routeModule:()=>p,tree:()=>d});var n=r(65239),i=r(48088),s=r(88170),a=r.n(s),o=r(30893),l={};for(let e in o)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);r.d(t,l);let d={children:["",{children:["chat",{children:["[listing_id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,43620)),"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\chat\\[listing_id]\\page.tsx"]}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,94431)),"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,54431)),"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,c=["C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\chat\\[listing_id]\\page.tsx"],u={require:r,loadChunk:()=>Promise.resolve()},p=new n.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/chat/[listing_id]/page",pathname:"/chat/[listing_id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},41662:(e,t,r)=>{var n={"./en.json":[4213,213],"./id.json":[38163,163],"./ph.json":[2762,762],"./th.json":[16406,406]};function i(e){if(!r.o(n,e))return Promise.resolve().then(()=>{var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t});var t=n[e],i=t[0];return r.e(t[1]).then(()=>r.t(i,19))}i.keys=()=>Object.keys(n),i.id=41662,e.exports=i},43620:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Admin\\\\Documents\\\\marketplace-mmorpg\\\\src\\\\app\\\\chat\\\\[listing_id]\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\chat\\[listing_id]\\page.tsx","default")},53332:(e,t,r)=>{"use strict";var n=r(43210),i="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},s=n.useState,a=n.useEffect,o=n.useLayoutEffect,l=n.useDebugValue;function d(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!i(e,r)}catch(e){return!0}}var c="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var r=t(),n=s({inst:{value:r,getSnapshot:t}}),i=n[0].inst,c=n[1];return o(function(){i.value=r,i.getSnapshot=t,d(i)&&c({inst:i})},[e,r,t]),a(function(){return d(i)&&c({inst:i}),e(function(){d(i)&&c({inst:i})})},[e]),l(r),r};t.useSyncExternalStore=void 0!==n.useSyncExternalStore?n.useSyncExternalStore:c},54431:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Admin\\\\Documents\\\\marketplace-mmorpg\\\\src\\\\app\\\\error.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\error.tsx","default")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57379:(e,t,r)=>{"use strict";e.exports=r(53332)},60534:(e,t,r)=>{"use strict";r.d(t,{default:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Admin\\\\Documents\\\\marketplace-mmorpg\\\\src\\\\app\\\\ClientLayout.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Admin\\Documents\\marketplace-mmorpg\\src\\app\\ClientLayout.tsx","default")},61135:()=>{},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66651:(e,t,r)=>{Promise.resolve().then(r.bind(r,14329))},70440:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>i});var n=r(31658);let i=async e=>[{type:"image/x-icon",sizes:"16x16",url:(0,n.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]},73247:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,86346,23)),Promise.resolve().then(r.t.bind(r,27924,23)),Promise.resolve().then(r.t.bind(r,35656,23)),Promise.resolve().then(r.t.bind(r,40099,23)),Promise.resolve().then(r.t.bind(r,38243,23)),Promise.resolve().then(r.t.bind(r,28827,23)),Promise.resolve().then(r.t.bind(r,62763,23)),Promise.resolve().then(r.t.bind(r,97173,23))},74075:e=>{"use strict";e.exports=require("zlib")},78564:(e,t,r)=>{"use strict";let n;r.r(t),r.d(t,{default:()=>e0});var i,s=r(60687),a=r(43210),o=r(16189),l=r(16391),d=r(57379),c=Object.prototype.hasOwnProperty;let u=new WeakMap,p=()=>{},m=p(),f=Object,h=e=>e===m,g=e=>"function"==typeof e,b=(e,t)=>({...e,...t}),x=e=>g(e.then),v={},y={},w="undefined",k=typeof document!=w,C=!1,P=()=>!1,_=(e,t)=>{let r=u.get(e);return[()=>!h(t)&&e.get(t)||v,n=>{if(!h(t)){let i=e.get(t);t in y||(y[t]=i),r[5](t,b(i,n),i||v)}},r[6],()=>!h(t)&&t in y?y[t]:!h(t)&&e.get(t)||v]},O=!0,[S,D]=[p,p],E={initFocus:e=>(k&&document.addEventListener("visibilitychange",e),S("focus",e),()=>{k&&document.removeEventListener("visibilitychange",e),D("focus",e)}),initReconnect:e=>{let t=()=>{O=!0,e()},r=()=>{O=!1};return S("online",t),S("offline",r),()=>{D("online",t),D("offline",r)}}},R=!a.useId,I=!0,A=e=>P()?window.requestAnimationFrame(e):setTimeout(e,1),N=I?a.useEffect:a.useLayoutEffect,M="undefined"!=typeof navigator&&navigator.connection,T=!I&&M&&(["slow-2g","2g"].includes(M.effectiveType)||M.saveData),L=new WeakMap,q=(e,t)=>f.prototype.toString.call(e)===`[object ${t}]`,$=0,U=e=>{let t,r,n=typeof e,i=q(e,"Date"),s=q(e,"RegExp"),a=q(e,"Object");if(f(e)!==e||i||s)t=i?e.toJSON():"symbol"==n?e.toString():"string"==n?JSON.stringify(e):""+e;else{if(t=L.get(e))return t;if(t=++$+"~",L.set(e,t),Array.isArray(e)){for(r=0,t="@";r<e.length;r++)t+=U(e[r])+",";L.set(e,t)}if(a){t="#";let n=f.keys(e).sort();for(;!h(r=n.pop());)h(e[r])||(t+=r+":"+U(e[r])+",");L.set(e,t)}}return t},V=e=>{if(g(e))try{e=e()}catch(t){e=""}let t=e;return[e="string"==typeof e?e:(Array.isArray(e)?e.length:e)?U(e):"",t]},F=0,z=()=>++F;async function G(...e){let[t,r,n,i]=e,s=b({populateCache:!0,throwOnError:!0},"boolean"==typeof i?{revalidate:i}:i||{}),a=s.populateCache,o=s.rollbackOnError,l=s.optimisticData,d=e=>"function"==typeof o?o(e):!1!==o,c=s.throwOnError;if(g(r)){let e=[];for(let n of t.keys())!/^\$(inf|sub)\$/.test(n)&&r(t.get(n)._k)&&e.push(n);return Promise.all(e.map(p))}return p(r);async function p(r){let i,[o]=V(r);if(!o)return;let[p,f]=_(t,o),[b,v,y,w]=u.get(t),k=()=>{let e=b[o];return(g(s.revalidate)?s.revalidate(p().data,r):!1!==s.revalidate)&&(delete y[o],delete w[o],e&&e[0])?e[0](2).then(()=>p().data):p().data};if(e.length<3)return k();let C=n,P=z();v[o]=[P,0];let O=!h(l),S=p(),D=S.data,E=S._c,R=h(E)?D:E;if(O&&f({data:l=g(l)?l(R,D):l,_c:R}),g(C))try{C=C(R)}catch(e){i=e}if(C&&x(C)){if(C=await C.catch(e=>{i=e}),P!==v[o][0]){if(i)throw i;return C}i&&O&&d(i)&&(a=!0,f({data:R,_c:m}))}if(a&&!i&&(g(a)?f({data:a(C,R),error:m,_c:m}):f({data:C,error:m,_c:m})),v[o][1]=z(),Promise.resolve(k()).then(()=>{f({_c:m})}),i){if(c)throw i;return}return C}}let J=(e,t)=>{for(let r in e)e[r][0]&&e[r][0](t)},W=(e,t)=>{if(!u.has(e)){let r=b(E,t),n=Object.create(null),i=G.bind(m,e),s=p,a=Object.create(null),o=(e,t)=>{let r=a[e]||[];return a[e]=r,r.push(t),()=>r.splice(r.indexOf(t),1)},l=(t,r,n)=>{e.set(t,r);let i=a[t];if(i)for(let e of i)e(r,n)},d=()=>{if(!u.has(e)&&(u.set(e,[n,Object.create(null),Object.create(null),Object.create(null),i,l,o]),!I)){let t=r.initFocus(setTimeout.bind(m,J.bind(m,n,0))),i=r.initReconnect(setTimeout.bind(m,J.bind(m,n,1)));s=()=>{t&&t(),i&&i(),u.delete(e)}}};return d(),[e,i,d,s]}return[e,u.get(e)[4]]},[X,Z]=W(new Map),B=b({onLoadingSlow:p,onSuccess:p,onError:p,onErrorRetry:(e,t,r,n,i)=>{let s=r.errorRetryCount,a=i.retryCount,o=~~((Math.random()+.5)*(1<<(a<8?a:8)))*r.errorRetryInterval;(h(s)||!(a>s))&&setTimeout(n,o,i)},onDiscarded:p,revalidateOnFocus:!0,revalidateOnReconnect:!0,revalidateIfStale:!0,shouldRetryOnError:!0,errorRetryInterval:T?1e4:5e3,focusThrottleInterval:5e3,dedupingInterval:2e3,loadingTimeout:T?5e3:3e3,compare:function e(t,r){var n,i;if(t===r)return!0;if(t&&r&&(n=t.constructor)===r.constructor){if(n===Date)return t.getTime()===r.getTime();if(n===RegExp)return t.toString()===r.toString();if(n===Array){if((i=t.length)===r.length)for(;i--&&e(t[i],r[i]););return -1===i}if(!n||"object"==typeof t){for(n in i=0,t)if(c.call(t,n)&&++i&&!c.call(r,n)||!(n in r)||!e(t[n],r[n]))return!1;return Object.keys(r).length===i}}return t!=t&&r!=r},isPaused:()=>!1,cache:X,mutate:Z,fallback:{}},{isOnline:()=>O,isVisible:()=>{let e=k&&document.visibilityState;return h(e)||"hidden"!==e}}),K=(e,t)=>{let r=b(e,t);if(t){let{use:n,fallback:i}=e,{use:s,fallback:a}=t;n&&s&&(r.use=n.concat(s)),i&&a&&(r.fallback=b(i,a))}return r},Y=(0,a.createContext)({}),ee=!1,et=ee?window.__SWR_DEVTOOLS_USE__:[],er=e=>g(e[1])?[e[0],e[1],e[2]||{}]:[e[0],null,(null===e[1]?e[2]:e[1])||{}],en=()=>b(B,(0,a.useContext)(Y)),ei=et.concat(e=>(t,r,n)=>{let i=r&&((...e)=>{let[n]=V(t),[,,,i]=u.get(X);if(n.startsWith("$inf$"))return r(...e);let s=i[n];return h(s)?r(...e):(delete i[n],s)});return e(t,i,n)}),es=(e,t,r)=>{let n=t[e]||(t[e]=[]);return n.push(r),()=>{let e=n.indexOf(r);e>=0&&(n[e]=n[n.length-1],n.pop())}};ee&&(window.__SWR_DEVTOOLS_REACT__=a);let ea=()=>{},eo=ea();new WeakMap;let el=a.use||(e=>{switch(e.status){case"pending":throw e;case"fulfilled":return e.value;case"rejected":throw e.reason;default:throw e.status="pending",e.then(t=>{e.status="fulfilled",e.value=t},t=>{e.status="rejected",e.reason=t}),e}}),ed={dedupe:!0};f.defineProperty(e=>{let{value:t}=e,r=(0,a.useContext)(Y),n=g(t),i=(0,a.useMemo)(()=>n?t(r):t,[n,r,t]),s=(0,a.useMemo)(()=>n?i:K(r,i),[n,r,i]),o=i&&i.provider,l=(0,a.useRef)(m);o&&!l.current&&(l.current=W(o(s.cache||X),i));let d=l.current;return d&&(s.cache=d[0],s.mutate=d[1]),N(()=>{if(d)return d[2]&&d[2](),d[3]},[]),(0,a.createElement)(Y.Provider,b(e,{value:s}))},"defaultValue",{value:B});let ec=(n=(e,t,r)=>{let{cache:n,compare:i,suspense:s,fallbackData:o,revalidateOnMount:l,revalidateIfStale:c,refreshInterval:p,refreshWhenHidden:f,refreshWhenOffline:v,keepPreviousData:y}=r,[w,k,C,P]=u.get(n),[O,S]=V(e),D=(0,a.useRef)(!1),E=(0,a.useRef)(!1),M=(0,a.useRef)(O),T=(0,a.useRef)(t),L=(0,a.useRef)(r),q=()=>L.current,$=()=>q().isVisible()&&q().isOnline(),[U,F,J,W]=_(n,O),X=(0,a.useRef)({}).current,Z=h(o)?h(r.fallback)?m:r.fallback[O]:o,B=(e,t)=>{for(let r in X)if("data"===r){if(!i(e[r],t[r])&&(!h(e[r])||!i(eo,t[r])))return!1}else if(t[r]!==e[r])return!1;return!0},K=(0,a.useMemo)(()=>{let e=!!O&&!!t&&(h(l)?!q().isPaused()&&!s&&!1!==c:l),r=t=>{let r=b(t);return(delete r._k,e)?{isValidating:!0,isLoading:!0,...r}:r},n=U(),i=W(),a=r(n),o=n===i?a:r(i),d=a;return[()=>{let e=r(U());return B(e,d)?(d.data=e.data,d.isLoading=e.isLoading,d.isValidating=e.isValidating,d.error=e.error,d):(d=e,e)},()=>o]},[n,O]),Y=(0,d.useSyncExternalStore)((0,a.useCallback)(e=>J(O,(t,r)=>{B(r,t)||e()}),[n,O]),K[0],K[1]),ee=!D.current,et=w[O]&&w[O].length>0,er=Y.data,en=h(er)?Z&&x(Z)?el(Z):Z:er,ei=Y.error,ea=(0,a.useRef)(en),eo=y?h(er)?h(ea.current)?en:ea.current:er:en,ec=(!et||!!h(ei))&&(ee&&!h(l)?l:!q().isPaused()&&(s?!h(en)&&c:h(en)||c)),eu=!!(O&&t&&ee&&ec),ep=h(Y.isValidating)?eu:Y.isValidating,em=h(Y.isLoading)?eu:Y.isLoading,ef=(0,a.useCallback)(async e=>{let t,n,s=T.current;if(!O||!s||E.current||q().isPaused())return!1;let a=!0,o=e||{},l=!C[O]||!o.dedupe,d=()=>R?!E.current&&O===M.current&&D.current:O===M.current,c={isValidating:!1,isLoading:!1},u=()=>{F(c)},p=()=>{let e=C[O];e&&e[1]===n&&delete C[O]},f={isValidating:!0};h(U().data)&&(f.isLoading=!0);try{if(l&&(F(f),r.loadingTimeout&&h(U().data)&&setTimeout(()=>{a&&d()&&q().onLoadingSlow(O,r)},r.loadingTimeout),C[O]=[s(S),z()]),[t,n]=C[O],t=await t,l&&setTimeout(p,r.dedupingInterval),!C[O]||C[O][1]!==n)return l&&d()&&q().onDiscarded(O),!1;c.error=m;let e=k[O];if(!h(e)&&(n<=e[0]||n<=e[1]||0===e[1]))return u(),l&&d()&&q().onDiscarded(O),!1;let o=U().data;c.data=i(o,t)?o:t,l&&d()&&q().onSuccess(t,O,r)}catch(r){p();let e=q(),{shouldRetryOnError:t}=e;!e.isPaused()&&(c.error=r,l&&d()&&(e.onError(r,O,e),(!0===t||g(t)&&t(r))&&(!q().revalidateOnFocus||!q().revalidateOnReconnect||$())&&e.onErrorRetry(r,O,e,e=>{let t=w[O];t&&t[0]&&t[0](3,e)},{retryCount:(o.retryCount||0)+1,dedupe:!0})))}return a=!1,u(),!0},[O,n]),eh=(0,a.useCallback)((...e)=>G(n,M.current,...e),[]);if(N(()=>{T.current=t,L.current=r,h(er)||(ea.current=er)}),N(()=>{if(!O)return;let e=ef.bind(m,ed),t=0;q().revalidateOnFocus&&(t=Date.now()+q().focusThrottleInterval);let r=es(O,w,(r,n={})=>{if(0==r){let r=Date.now();q().revalidateOnFocus&&r>t&&$()&&(t=r+q().focusThrottleInterval,e())}else if(1==r)q().revalidateOnReconnect&&$()&&e();else if(2==r)return ef();else if(3==r)return ef(n)});return E.current=!1,M.current=O,D.current=!0,F({_k:S}),ec&&(h(en)||I?e():A(e)),()=>{E.current=!0,r()}},[O]),N(()=>{let e;function t(){let t=g(p)?p(U().data):p;t&&-1!==e&&(e=setTimeout(r,t))}function r(){!U().error&&(f||q().isVisible())&&(v||q().isOnline())?ef(ed).then(t):t()}return t(),()=>{e&&(clearTimeout(e),e=-1)}},[p,f,v,O]),(0,a.useDebugValue)(eo),s&&h(en)&&O){if(!R&&I)throw Error("Fallback data is required when using Suspense in SSR.");T.current=t,L.current=r,E.current=!1;let e=P[O];if(h(e)||el(eh(e)),h(ei)){let e=ef(ed);h(eo)||(e.status="fulfilled",e.value=!0),el(e)}else throw ei}return{mutate:eh,get data(){return X.data=!0,eo},get error(){return X.error=!0,ei},get isValidating(){return X.isValidating=!0,ep},get isLoading(){return X.isLoading=!0,em}}},function(...e){let t=en(),[r,i,s]=er(e),a=K(t,s),o=n,{use:l}=a,d=(l||[]).concat(ei);for(let e=d.length;e--;)o=d[e](o);return o(r,i||a.fetcher||null,a)});var eu=r(27605);let ep={data:""},em=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||ep,ef=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,eh=/\/\*[^]*?\*\/|  +/g,eg=/\n+/g,eb=(e,t)=>{let r="",n="",i="";for(let s in e){let a=e[s];"@"==s[0]?"i"==s[1]?r=s+" "+a+";":n+="f"==s[1]?eb(a,s):s+"{"+eb(a,"k"==s[1]?"":t)+"}":"object"==typeof a?n+=eb(a,t?t.replace(/([^,])+/g,e=>s.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):s):null!=a&&(s=/^--/.test(s)?s:s.replace(/[A-Z]/g,"-$&").toLowerCase(),i+=eb.p?eb.p(s,a):s+":"+a+";")}return r+(t&&i?t+"{"+i+"}":i)+n},ex={},ev=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+ev(e[r]);return t}return e},ey=(e,t,r,n,i)=>{let s=ev(e),a=ex[s]||(ex[s]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(s));if(!ex[a]){let t=s!==e?e:(e=>{let t,r,n=[{}];for(;t=ef.exec(e.replace(eh,""));)t[4]?n.shift():t[3]?(r=t[3].replace(eg," ").trim(),n.unshift(n[0][r]=n[0][r]||{})):n[0][t[1]]=t[2].replace(eg," ").trim();return n[0]})(e);ex[a]=eb(i?{["@keyframes "+a]:t}:t,r?"":"."+a)}let o=r&&ex.g?ex.g:null;return r&&(ex.g=ex[a]),((e,t,r,n)=>{n?t.data=t.data.replace(n,e):-1===t.data.indexOf(e)&&(t.data=r?e+t.data:t.data+e)})(ex[a],t,n,o),a},ew=(e,t,r)=>e.reduce((e,n,i)=>{let s=t[i];if(s&&s.call){let e=s(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;s=t?"."+t:e&&"object"==typeof e?e.props?"":eb(e,""):!1===e?"":e}return e+n+(null==s?"":s)},"");function ej(e){let t=this||{},r=e.call?e(t.p):e;return ey(r.unshift?r.raw?ew(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,em(t.target),t.g,t.o,t.k)}ej.bind({g:1});let ek,eC,eP,e_=ej.bind({k:1});function eO(e,t){let r=this||{};return function(){let n=arguments;function i(s,a){let o=Object.assign({},s),l=o.className||i.className;r.p=Object.assign({theme:eC&&eC()},o),r.o=/ *go\d+/.test(l),o.className=ej.apply(r,n)+(l?" "+l:""),t&&(o.ref=a);let d=e;return e[0]&&(d=o.as||e,delete o.as),eP&&d[0]&&eP(o),ek(d,o)}return t?t(i):i}}var eS=e=>"function"==typeof e,eD=(e,t)=>eS(e)?e(t):e,eE=(()=>{let e=0;return()=>(++e).toString()})(),eR=(()=>{let e;return()=>e})(),eI=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return eI(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:n}=t;return{...e,toasts:e.toasts.map(e=>e.id===n||void 0===n?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},eA=[],eN={toasts:[],pausedAt:void 0},eM=e=>{eN=eI(eN,e),eA.forEach(e=>{e(eN)})},eT={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},eL=(e={})=>{let[t,r]=j(eN),n=Q(eN);H(()=>(n.current!==eN&&r(eN),eA.push(r),()=>{let e=eA.indexOf(r);e>-1&&eA.splice(e,1)}),[]);let i=t.toasts.map(t=>{var r,n,i;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(n=e[t.type])?void 0:n.duration)||(null==e?void 0:e.duration)||eT[t.type],style:{...e.style,...null==(i=e[t.type])?void 0:i.style,...t.style}}});return{...t,toasts:i}},eq=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||eE()}),e$=e=>(t,r)=>{let n=eq(t,e,r);return eM({type:2,toast:n}),n.id},eU=(e,t)=>e$("blank")(e,t);eU.error=e$("error"),eU.success=e$("success"),eU.loading=e$("loading"),eU.custom=e$("custom"),eU.dismiss=e=>{eM({type:3,toastId:e})},eU.remove=e=>eM({type:4,toastId:e}),eU.promise=(e,t,r)=>{let n=eU.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let i=t.success?eD(t.success,e):void 0;return i?eU.success(i,{id:n,...r,...null==r?void 0:r.success}):eU.dismiss(n),e}).catch(e=>{let i=t.error?eD(t.error,e):void 0;i?eU.error(i,{id:n,...r,...null==r?void 0:r.error}):eU.dismiss(n)}),e};var eV=(e,t)=>{eM({type:1,toast:{id:e,height:t}})},eF=()=>{eM({type:5,time:Date.now()})},ez=new Map,eG=1e3,eJ=(e,t=eG)=>{if(ez.has(e))return;let r=setTimeout(()=>{ez.delete(e),eM({type:4,toastId:e})},t);ez.set(e,r)},eW=e_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,eX=e_`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,eZ=e_`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,eB=(eO("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${eW} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${eX} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${eZ} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,e_`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),eH=(eO("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${eB} 1s linear infinite;
`,e_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),eK=e_`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,eY=(eO("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${eH} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${eK} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,eO("div")`
  position: absolute;
`,eO("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,e_`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);eO("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${eY} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,eO("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eO("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,i=a.createElement,eb.p=void 0,ek=i,eC=void 0,eP=void 0,ej`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;let eQ=async e=>{let{data:t}=await l.N.auth.getUser(),r=t.user?.id;if(!r)return{chat:null,messages:[]};let{data:n}=await l.N.from("chats").select("id").eq("listing_id",e).or(`buyer_id.eq.${r},seller_id.eq.${r}`).single();if(!n)return{chat:null,messages:[]};let{data:i}=await l.N.from("messages").select("id, sender_id, content, created_at").eq("chat_id",n.id).order("created_at",{ascending:!0});return{chat:n,messages:i||[]}};function e0(){let e=(0,o.useParams)(),t=Array.isArray(e?.listing_id)?e.listing_id[0]:e?.listing_id,[r,n]=(0,a.useState)(0),{register:i,handleSubmit:d,reset:c}=(0,eu.mN)(),[u,p]=(0,a.useState)(!1),[m,f]=(0,a.useState)(null),h=(0,a.useRef)(null),{data:g,mutate:b}=ec(t,eQ,{refreshInterval:0}),x=async e=>{if(!e.content||!g?.chat||!m)return;p(!0);let{error:t}=await l.N.from("messages").insert({chat_id:g.chat.id,sender_id:m,content:e.content});p(!1),t?eU.error("Gagal mengirim pesan"):c()};return g?g.chat?(0,s.jsxs)("div",{className:"max-w-lg mx-auto flex flex-col h-[80vh] border rounded shadow bg-white",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between px-4 py-3 border-b bg-blue-50",children:[(0,s.jsx)("span",{className:"font-bold text-blue-900",children:"Chat Transaksi"}),r>0&&(0,s.jsx)("span",{className:"bg-red-500 text-white text-xs rounded-full px-2 py-0.5 ml-2",children:r})]}),(0,s.jsxs)("div",{className:"flex-1 overflow-y-auto px-4 py-2 space-y-2 bg-blue-50",children:[g.messages.map(e=>(0,s.jsx)("div",{className:`flex ${e.sender_id===m?"justify-end":"justify-start"}`,children:(0,s.jsxs)("div",{className:`rounded-2xl px-4 py-2 max-w-[70%] text-sm shadow ${e.sender_id===m?"bg-blue-600 text-white":"bg-white text-blue-900 border"}`,children:[e.content,(0,s.jsx)("div",{className:"text-[10px] text-right mt-1 opacity-60",children:new Date(e.created_at).toLocaleTimeString()})]})},e.id)),(0,s.jsx)("div",{ref:h})]}),(0,s.jsxs)("form",{onSubmit:d(x),className:"flex gap-2 p-3 border-t bg-white",children:[(0,s.jsx)("input",{type:"text",...i("content"),placeholder:"Ketik pesan...",className:"flex-1 border rounded-full px-4 py-2 focus:outline-none",autoComplete:"off"}),(0,s.jsx)("button",{type:"submit",disabled:u,className:"bg-blue-600 text-white px-4 py-2 rounded-full font-semibold hover:bg-blue-700 transition",children:"Kirim"})]})]}):(0,s.jsx)("div",{className:"text-center py-12",children:"Chat tidak ditemukan."}):(0,s.jsx)("div",{className:"text-center py-12",children:"Loading chat..."})}},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},88626:(e,t,r)=>{Promise.resolve().then(r.bind(r,43620))},91399:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,16444,23)),Promise.resolve().then(r.t.bind(r,16042,23)),Promise.resolve().then(r.t.bind(r,88170,23)),Promise.resolve().then(r.t.bind(r,49477,23)),Promise.resolve().then(r.t.bind(r,29345,23)),Promise.resolve().then(r.t.bind(r,12089,23)),Promise.resolve().then(r.t.bind(r,46577,23)),Promise.resolve().then(r.t.bind(r,31307,23))},91645:e=>{"use strict";e.exports=require("net")},94431:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>p,metadata:()=>c});var n=r(37413),i=r(22376),s=r.n(i),a=r(68726),o=r.n(a);r(61135);var l=r(60534),d=r(29519);let c={title:"Marketplace MMORPG SEA",description:"Jual beli item, gold, jasa game MMORPG Asia Tenggara. Aman, cepat, terpercaya."};async function u(e){try{return(await r(41662)(`./${e}.json`)).default}catch(t){return console.error(`Failed to load messages for locale: ${e}`,t),{}}}async function p({children:e}){let t=await u("id");return(0,n.jsx)("html",{lang:"id",children:(0,n.jsx)("body",{className:`${s().variable} ${o().variable} antialiased`,children:(0,n.jsx)(d.Providers,{messages:t,locale:"id",children:(0,n.jsx)(l.default,{children:e})})})})}},94735:e=>{"use strict";e.exports=require("events")},96861:(e,t,r)=>{"use strict";r.d(t,{default:()=>l});var n=r(60687),i=r(43210),s=r(42918);function a(){let[e,t]=(0,i.useState)(!1);return(0,n.jsxs)("nav",{className:"w-full flex items-center justify-between px-6 py-3 bg-background border-b border-gray-200 dark:border-gray-800",children:[(0,n.jsx)("div",{className:"font-bold text-xl text-brand",children:"Marketplace MMORPG"}),(0,n.jsx)("button",{onClick:()=>{let r=!e;t(r),document.documentElement.classList.toggle("dark",r),localStorage.setItem("theme",r?"dark":"light")},className:"rounded-full p-2 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 shadow hover:bg-gray-100 dark:hover:bg-gray-800 transition","aria-label":"Toggle dark mode",children:e?(0,n.jsx)("span",{title:"Light Mode",children:"\uD83C\uDF1E"}):(0,n.jsx)("span",{title:"Dark Mode",children:"\uD83C\uDF19"})})]})}function o({error:e}){return(0,n.jsxs)("div",{className:"flex flex-col items-center justify-center min-h-screen p-8",children:[(0,n.jsx)("h2",{className:"text-2xl font-bold text-red-600 mb-4",children:"Something went wrong:"}),(0,n.jsx)("pre",{className:"text-sm bg-red-50 p-4 rounded",children:e.message})]})}function l({children:e}){return(0,n.jsxs)(s.tH,{FallbackComponent:o,children:[(0,n.jsx)(a,{}),e]})}r(46060)}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[447,710,658,25,605],()=>r(36404));module.exports=n})();